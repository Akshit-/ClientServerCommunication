//
//  HomeViewController.swift
//  RegistrationApp
//
//  Created by Akshit Malhotra on 9/26/14.
//  Copyright (c) 2014 LS1 TUM. All rights reserved.
//

import Foundation
import UIKit

class HomeViewController: UIViewController {
    
    
}